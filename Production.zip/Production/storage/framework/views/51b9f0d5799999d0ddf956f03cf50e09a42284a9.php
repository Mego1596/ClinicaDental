<?php $__env->startSection('titulo'); ?>
    Detalles de Usuario
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 style="text-align: center;"><strong>Detalles de Usuario</strong></h1>
<?php if(count($errors) > 0): ?>
	<div class="alert alert-danger" role="alert">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
<?php if(session()->has('danger')): ?>
	<div class="alert alert-danger" role="alert"><?php echo e(session('danger')); ?></div>
<?php endif; ?>
<form>
	<div class="form-group row col-sm-12">
	    <label for="primer_nombre" class="col-sm-2 col-form-label">Primer nombre:</label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="primer_nombre" value="<?php echo e($user->persona->primer_nombre); ?>" readonly disabled>
	    </div>
	    <label for="segundo_nombre" class="col-sm-2 col-form-label">Segundo nombre:</label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="segundo_nombre" value="<?php echo e($user->persona->segundo_nombre); ?>" readonly disabled>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="primer_apellido" class="col-sm-2 col-form-label">Primer apellido:</label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="primer_apellido" value="<?php echo e($user->persona->primer_apellido); ?>" readonly disabled>
	    </div>
	    <label for="segundo_apellido" class="col-sm-2 col-form-label">Segundo apellido:</label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="segundo_apellido" value="<?php echo e($user->persona->segundo_apellido); ?>" readonly disabled>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="telefono" class="col-sm-2 col-form-label">Número de Teléfono:</label>
	    <div class="col-sm-4">
	      	<input id="telefono" type="text" class="form-control" name="telefono" value="<?php echo e($user->persona->telefono); ?>" readonly disabled>
	    </div>
	    <label for="email" class="col-sm-2 col-form-label">E-Mail</label>
	    <div class="col-sm-4">
	      <input type="email" class="form-control" id="email" name="email" value="<?php echo e($user->email); ?>" readonly disabled>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="direccion" class="col-sm-2 col-form-label">Direccion:</label>
	    <div class="col-sm-4">
	      	<textarea id="direccion" class="form-control" name="direccion" rows="4" readonly disabled><?php echo e($user->persona->direccion); ?></textarea>
			<?php if($errors->has('direccion')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('direccion')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>

	    <label for="role" class="col-sm-2" >Tipo de Usuario:</label>
		<div class="col-sm-4">
	      	<select required class="form-control" name="role" id="role" style="padding: -100%" readonly disabled>
				<option value="" disabled selected>Seleccione el tipo de usuario</option>
				<?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($user->roles[0]['slug'] == $rol->slug): ?>
						<option value="<?php echo e($rol->slug); ?>" selected><?php echo e($rol->name); ?></option>
					<?php else: ?>
						<option value="<?php echo e($rol->slug); ?>"><?php echo e($rol->name); ?></option>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label id="label_junta" for="numero_junta" class="col-sm-2" style="display: none">Número de Junta:</label>
		<div class="col-sm-4" id="div_junta" style="display: none">
	      	<input id="numero_junta" type="text" class="form-control" name="numero_junta" value="<?php echo e($user->persona->numero_junta); ?>" readonly disabled>
			<?php if($errors->has('numero_junta')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('numero_junta')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>

	<div class="d-flex justify-content-center">
		<a href="<?php echo e(route('users.index')); ?>" class="btn btn-danger"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
	</div>
</form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#telefono').mask('0000-0000')
		$('#telefono').attr('placeholder','####-####')
		if($('#role').val() == 'doctor'){
			$('#label_junta').css('display','block');
			$('#div_junta').css('display','block');
		}
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/usuarios/show_user.blade.php ENDPATH**/ ?>