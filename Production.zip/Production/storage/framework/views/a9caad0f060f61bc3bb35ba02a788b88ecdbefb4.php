<?php $__env->startSection('titulo'); ?>
    Registrar Cita
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 style="text-align: center;"><strong>Registrar Cita</strong></h1>
<?php if(count($errors) > 0): ?>
	<div class="alert alert-danger" role="alert">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
<?php $__env->startSection('CSS'); ?>
<link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.css">
<?php $__env->stopSection(); ?>
<?php if(session()->has('danger')): ?>
	<div class="alert alert-danger" role="alert"><?php echo e(session('danger')); ?></div>
<?php endif; ?>
<form autocomplete="off" method="POST" action="<?php echo e(route('citas.store')); ?>">
	<?php echo csrf_field(); ?>
	<div class="form-group row col-sm-12">
	    <label for="fecha_hora_inicio" class="col-sm-6 col-form-label">Fecha y hora de inicio:<font color="red">*</font></label>
	    <div class="col-sm-6">
            <input id="fecha_hora_inicio" type='datetime-local' class="form-control" name="fecha_hora_inicio" value="<?php echo e(old('fecha_hora_inicio')); ?>" required />
	      	<?php if($errors->has('fecha_hora_inicio')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('fecha_hora_inicio')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="fecha_hora_fin" class="col-sm-6 col-form-label">Fecha y hora de finalización:<font color="red">*</font></label>
	    <div class="col-sm-6">
	      	<input id="fecha_hora_fin" type="datetime-local" class="form-control" name="fecha_hora_fin" value="<?php echo e(old('fecha_hora_fin')); ?>">
	      	<?php if($errors->has('fecha_hora_fin')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('fecha_hora_fin')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="sexo" class="col-sm-6 col-form-label">Procedimiento:<font color="red">*</font></label>
	    <div class="col-sm-6">
	      <select class="form-control" name="sexo" required>
	      	<option value="" selected disabled>Seleccione</option>
	      	<?php $__currentLoopData = $procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	      		<option value="<?php echo e($procedimiento->id); ?>"><?php echo e($procedimiento->nombre); ?></option>
	      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	      </select>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="descripcion" class="col-sm-6 col-form-label">Descripción:</label>
	    <div class="col-sm-6">
	      	<input id="descripcion" type="text" class="form-control" name="descripcion" value="<?php echo e(old('descripcion')); ?>">
			<?php if($errors->has('descripcion')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('descripcion')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="d-flex justify-content-center">
		<button class="btn btn-success" style="margin-right: 1%"><i class="fa fa-save"></i> Guardar</button>
		<a href="<?php echo e(route('expedientes.index')); ?>" class="btn btn-danger"><i class="fas fa-arrow-circle-left"></i> Cancelar</a>
	</div>
</form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#telefono').mask('X000-0000',{ translation: { 'X': { pattern: /(2|7|6)/, optional: false } } })
		$('#telefono').attr('placeholder','####-####')
		$('#fecha_hora_fin').attr('disabled',true)
		$('#fecha_hora_inicio').change(function(){
			$('#fecha_hora_fin').attr('disabled',false).attr('min',$(this).val()).val($(this).val());
		})
	})
</script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-datetimepicker/2.5.20/jquery.datetimepicker.full.js"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/citas/create_cita.blade.php ENDPATH**/ ?>