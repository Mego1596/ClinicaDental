<?php $__env->startSection('titulo'); ?>
    Detalles del Paciente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('danger')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('danger'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<h1 style="text-align: center;"><strong>Detalles del Paciente</strong></h1>
	<div class="form-group row col-sm-12">
	    <label for="primer_nombre" class="col-sm-2 col-form-label">Primer nombre:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="primer_nombre" value="<?php echo e($expediente->persona->primer_nombre); ?>" readonly disabled>
	      	<?php if($errors->has('primer_nombre')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('primer_nombre')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="segundo_nombre" class="col-sm-2 col-form-label">Segundo nombre:</label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="segundo_nombre" value="<?php echo e($expediente->persona->segundo_nombre); ?>" readonly disabled>
	      	<?php if($errors->has('segundo_nombre')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('segundo_nombre')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="primer_apellido" class="col-sm-2 col-form-label">Primer apellido:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="primer_apellido" value="<?php echo e($expediente->persona->primer_apellido); ?>" readonly disabled>
	      	<?php if($errors->has('primer_apellido')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('primer_apellido')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="segundo_apellido" class="col-sm-2 col-form-label">Segundo apellido:</label>
	    <div class="col-sm-4">
	      	<input type="text" class="form-control" name="segundo_apellido" value="<?php echo e($expediente->persona->segundo_apellido); ?>" readonly disabled>
	      	<?php if($errors->has('segundo_apellido')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('segundo_apellido')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="telefono" class="col-sm-2 col-form-label">Número de Teléfono<font color="red">*</font></label>
	    <div class="col-sm-4">
	      	<input id="telefono" type="text" class="form-control" name="telefono" value="<?php echo e($expediente->persona->telefono); ?>" readonly disabled>
			<?php if($errors->has('telefono')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('telefono')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="email" class="col-sm-2 col-form-label">E-Mail:</label>
	    <div class="col-sm-4">
	    	<?php if(!is_null($expediente->persona->user)): ?>
	      		<input type="email" class="form-control" id="email" name="email" value="<?php echo e($expediente->persona->user->email); ?>" readonly disabled>
	      	<?php else: ?>
	      		<input type="email" class="form-control" id="email" name="email" readonly disabled>
	      	<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="fecha_nacimiento" class="col-sm-2 col-form-label">Fecha de nacimiento:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      	<input id="fecha_nacimiento" type="date" class="form-control" max="<?php echo e(Carbon\Carbon::now()->subYears(1)->format('Y-m-d')); ?>" name="fecha_nacimiento" value="<?php echo e($expediente->fecha_nacimiento); ?>" readonly disabled>
			<?php if($errors->has('fecha_nacimiento')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('fecha_nacimiento')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="sexo" class="col-sm-2 col-form-label">Género:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      <select class="form-control" name="sexo" readonly disabled>
	      	<option value="" disabled>Seleccione un género</option>
	      	<?php if($expediente->sexo == 'M'): ?>
	      		<option value="M" selected>Masculino</option>
	      		<option value="F">Femenino</option>
	      	<?php else: ?>
	      		<option value="M">Masculino</option>
	      		<option value="F" selected>Femenino</option>
	      	<?php endif; ?>
	      </select>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="responsable" class="col-sm-2 col-form-label">Responsable:</label>
	    <div class="col-sm-4">
	      	<input id="responsable" type="text" class="form-control" name="responsable" value="<?php echo e($expediente->responsable); ?>" readonly disabled>
			<?php if($errors->has('responsable')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('responsable')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="ocupacion" class="col-sm-2 col-form-label" >Ocupación:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      <select class="form-control" name="ocupacion" readonly disabled>
	      	<option value="" disabled>Seleccione una ocupación</option>
	      	<?php if($expediente->ocupacion == 'Estudiante'): ?>
		      	<option value="Estudiante" selected>Estudiante</option>
		      	<option value="Empleado">Empleado</option>
		      	<option value="Ama de casa">Ama de casa</option>
		      	<option value="Desempleado">Desempleado</option>
		      	<option value="Otros">Otros</option>
		    <?php endif; ?>
		    <?php if($expediente->ocupacion == 'Empleado'): ?>
		      	<option value="Estudiante">Estudiante</option>
		      	<option value="Empleado" selected>Empleado</option>
		      	<option value="Ama de casa">Ama de casa</option>
		      	<option value="Desempleado">Desempleado</option>
		      	<option value="Otros">Otros</option>
		    <?php endif; ?>
		    <?php if($expediente->ocupacion == 'Ama de casa'): ?>
		      	<option value="Estudiante">Estudiante</option>
		      	<option value="Empleado">Empleado</option>
		      	<option value="Ama de casa" selected>Ama de casa</option>
		      	<option value="Desempleado">Desempleado</option>
		      	<option value="Otros">Otros</option>
		    <?php endif; ?>
		    <?php if($expediente->ocupacion == 'Desempleado'): ?>
		      	<option value="Estudiante">Estudiante</option>
		      	<option value="Empleado">Empleado</option>
		      	<option value="Ama de casa">Ama de casa</option>
		      	<option value="Desempleado" selected>Desempleado</option>
		      	<option value="Otros">Otros</option>
		    <?php endif; ?>
		    <?php if($expediente->ocupacion == 'Otros'): ?>
		      	<option value="Estudiante">Estudiante</option>
		      	<option value="Empleado">Empleado</option>
		      	<option value="Ama de casa">Ama de casa</option>
		      	<option value="Desempleado">Desempleado</option>
		      	<option value="Otros" selected>Otros</option>
		    <?php endif; ?>
	      </select>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="direccion" class="col-sm-2 col-form-label">Domicilio:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      	<textarea id="direccion" class="form-control" name="direccion" rows="4" readonly disabled><?php echo e($expediente->persona->direccion); ?></textarea>
			<?php if($errors->has('direccion')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('direccion')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="direccion_trabajo" class="col-sm-2 col-form-label">Direccion de trabajo:</label>
	    <div class="col-sm-4">
	      	<textarea id="direccion_trabajo" class="form-control" name="direccion_trabajo" rows="4" readonly disabled><?php echo e($expediente->direccion_trabajo); ?></textarea>
			<?php if($errors->has('direccion_trabajo')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('direccion_trabajo')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="historia_odontologica" class="col-sm-2 col-form-label">Historia Odontologica:</label>
	    <div class="col-sm-4">
	      	<textarea id="historia_odontologica" class="form-control" name="historia_odontologica" rows="4" readonly disabled><?php echo e($expediente->historia_odontologica); ?></textarea>
			<?php if($errors->has('historia_odontologica')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('historia_odontologica')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="historia_medica" class="col-sm-2 col-form-label">Historia Medica:</label>
	    <div class="col-sm-4">
	        <textarea id="historia_medica" class="form-control" name="historia_medica" rows="4" readonly disabled><?php echo e($expediente->historia_medica); ?></textarea>
			<?php if($errors->has('historia_medica')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('historia_medica')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="recomendado" class="col-sm-2 col-form-label">Recomendado por:</label>
	    <div class="col-sm-4">
	      	<input id="recomendado" type="text" class="form-control" name="recomendado" value="<?php echo e($expediente->recomendado); ?>" readonly disabled>
			<?php if($errors->has('recomendado')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('recomendado')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="d-flex justify-content-center">
		<a href="<?php echo e(route('expedientes.index')); ?>" class="btn btn-danger"><i class="fas fa-arrow-circle-left"></i> Regresar</a>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/expedientes/show_expediente.blade.php ENDPATH**/ ?>