<?php $__env->startSection('titulo'); ?>
    Registrar Paciente
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 style="text-align: center;"><strong>Registrar Paciente</strong></h1>
<?php if(count($errors) > 0): ?>
	<div class="alert alert-danger" role="alert">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
<?php if(session()->has('danger')): ?>
	<div class="alert alert-danger" role="alert"><?php echo e(session('danger')); ?></div>
<?php endif; ?>
<form autocomplete="off" method="POST" action="<?php echo e(route('expedientes.store')); ?>">
	<?php echo csrf_field(); ?>
	<input type="hidden" name="especial" id="especial" value="especial">
	<input type="hidden" name="persona" id="persona" value="<?php echo e($persona->id); ?>">
	<div class="form-group row col-sm-12">
	    <label for="fecha_nacimiento" class="col-sm-2 col-form-label">Fecha de nacimiento:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      	<input id="fecha_nacimiento" type="date" class="form-control" max="<?php echo e(Carbon\Carbon::now()->subYears(1)->format('Y-m-d')); ?>" name="fecha_nacimiento" value="<?php echo e(old('fecha_nacimiento')); ?>" required>
			<?php if($errors->has('fecha_nacimiento')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('fecha_nacimiento')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="sexo" class="col-sm-2 col-form-label">Género:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      <select class="form-control" name="sexo" required>
	      	<option value="" selected disabled>Seleccione un género</option>
	      	<option value="M">Masculino</option>
	      	<option value="F">Femenino</option>
	      </select>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="responsable" class="col-sm-2 col-form-label">Responsable:</label>
	    <div class="col-sm-4">
	      	<input id="responsable" type="text" class="form-control" name="responsable" value="<?php echo e(old('responsable')); ?>">
			<?php if($errors->has('responsable')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('responsable')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="ocupacion" class="col-sm-2 col-form-label">Ocupación:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      <select class="form-control" name="ocupacion" required>
	      	<option value="" selected disabled>Seleccione una ocupación</option>
	      	<option value="Estudiante">Estudiante</option>
	      	<option value="Empleado">Empleado</option>
	      	<option value="Ama de casa">Ama de casa</option>
	      	<option value="Desempleado">Desempleado</option>
	      	<option value="Otros">Otros</option>
	      </select>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="direccion" class="col-sm-2 col-form-label">Domicilio:<font color="red">*</font></label>
	    <div class="col-sm-4">
	      	<textarea id="direccion" class="form-control" name="direccion" rows="4" required><?php echo e(old('direccion')); ?></textarea>
			<?php if($errors->has('direccion')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('direccion')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="direccion_trabajo" class="col-sm-2 col-form-label">Direccion de trabajo:</label>
	    <div class="col-sm-4">
	      	<textarea id="direccion_trabajo" class="form-control" name="direccion_trabajo" rows="4" ><?php echo e(old('direccion_trabajo')); ?></textarea>
			<?php if($errors->has('direccion_trabajo')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('direccion_trabajo')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="historia_odontologica" class="col-sm-2 col-form-label">Historia Odontologica:</label>
	    <div class="col-sm-4">
	      	<textarea id="historia_odontologica" class="form-control" name="historia_odontologica" rows="4"><?php echo e(old('historia_odontologica')); ?></textarea>
			<?php if($errors->has('historia_odontologica')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('historia_odontologica')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="historia_medica" class="col-sm-2 col-form-label">Historia Medica:</label>
	    <div class="col-sm-4">
	        <textarea id="historia_medica" class="form-control" name="historia_medica" rows="4" ><?php echo e(old('historia_medica')); ?></textarea>
			<?php if($errors->has('historia_medica')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('historia_medica')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	</div>
	<div class="form-group row col-sm-12">
	    <label for="recomendado" class="col-sm-2 col-form-label">Recomendado por:</label>
	    <div class="col-sm-4">
	      	<input id="recomendado" type="text" class="form-control" name="recomendado" value="<?php echo e(old('recomendado')); ?>">
			<?php if($errors->has('recomendado')): ?>
				<span class="help-block">
					<strong><?php echo e($errors->first('recomendado')); ?></strong>
				</span>
			<?php endif; ?>
	    </div>
	    <label for="email" class="col-sm-2 col-form-label">E-Mail:</label>
	    <div class="col-sm-4">
	    	<input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>">
	    </div>
	</div>
	<div class="d-flex justify-content-center">
		<button class="btn btn-success" style="margin-right: 1%"><i class="fa fa-save"></i> Guardar</button>
		<a href="<?php echo e(route('expedientes.index')); ?>" class="btn btn-danger"><i class="fas fa-arrow-circle-left"></i> Cancelar</a>
	</div>
</form>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script type="text/javascript">
	$(document).ready(function(){
		$('#telefono').mask('X000-0000',{ translation: { 'X': { pattern: /(2|7|6)/, optional: false } } })
		$('#telefono').attr('placeholder','####-####')
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/create_expediente_especial.blade.php ENDPATH**/ ?>