<?php $__env->startSection('titulo'); ?>
    Lista de Planes de Tratamiento
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('danger')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('danger'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<div class="panel-title">
    <h1 align="center" style="color: black">Lista de Planes de Tratamiento</h1>
</div>
<div class="table-responsive">
    <table width="100%">
        <tr>
            <td width="100%">
                <a class="btn btn-sm btn-danger" href="<?php echo e(route('expedientes.index')); ?>"><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
            </td>
        </tr>
    </table>
</div>
<br/>
<br/>
<div class="pull-bottom">
    <div class="table-responsive">
    <table class="table table-bordered" id="example" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>Fecha</th>
                <th>Numero de Plan</th>
                <th>Planes de Tratamiento</th>
                <th>Odontograma</th>
                
            </tr>
        </thead>
        <tbody>
            <?php
                $x=0;
            ?>
            <?php $__currentLoopData = $citas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cita.index')): ?>
                <tr>
                    <td align="center">
                        <?php
                            $date=date_create($cita->fecha_hora_inicio);
                            echo date_format($date,"d/m/Y");
                        ?>
                    </td>
                    <td align="right">
                        <?php
                            echo ++$x;
                        ?>
                    </td>
                    <td align="center">    
                        <a href="<?php echo e(route('expedientes.plan',['cita' => $cita->id])); ?>" class="btn btn-sm btn-info" style="color: white" target="_blank"><li class="fa fa-file-pdf-o"></li> Ver Plan de Tratamiento
                    </td>
                    <td align="center">
                        <?php if($loop->last): ?>
                            <?php if(sizeof($cita->odontogramas) == 0): ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('odontograma.create')): ?>
                                    <a href="<?php echo e(route('odontogramas.tratamiento',['cita' => $cita->id])); ?>" class="btn btn-circle btn-primary" style="color: white"><li class="fas fa-tooth"></li>
                                <?php endif; ?>
                            <?php else: ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('odontograma.destroy')): ?>
                                    <?php $__currentLoopData = $cita->odontogramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $odontograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($odontograma->activo == 1): ?>
                                            <!-- Button trigger modal -->
                                            <button type="button" class="btn btn-danger btn-circle" data-toggle="modal" data-target="#eliminarOdontograma">
                                                <i class="fas fa-trash-alt"></i>
                                            </button>

                                            <!-- Modal -->
                                            <div class="modal fade" id="eliminarOdontograma" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                <div class="modal-dialog" role="document">
                                                    <div class="modal-content">
                                                        <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel">Eliminar odontograma</h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                        </div>
                                                        <div class="modal-body">
                                                            <h3>Esta seguro que desea eliminar este odontograma?</h3>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                                                            <form method="POST" action="<?php echo e(route('odontogramas.destroy',['odontograma' => $odontograma->id])); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo e(method_field('DELETE')); ?>

                                                                <button type="submit" class="btn btn-danger">Si</button>
                                                            </form>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        <?php else: ?>
                                            <?php if($loop->last): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('odontograma.create')): ?>
                                                    <a href="<?php echo e(route('odontogramas.tratamiento',['cita' => $cita->id])); ?>" class="btn btn-circle btn-primary" style="color: white"><li class="fas fa-tooth"></li>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script type="text/javascript">
    $(function () {
        $('#example').DataTable({
            "language": {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
                },
            responsive:true,
            pagingType: "simple",
            "columnDefs": [
                { "orderable": false, "targets": [2,3] }
            ]
        });
        
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/expedientes/planes_tratamiento.blade.php ENDPATH**/ ?>