<?php $__env->startSection('titulo'); ?>
    Lista de Procedimientos
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('danger')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('danger'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<div class="panel-title">
    <h1 align="center" style="color: black">Lista de Procedimientos</h1>
</div>
<div class="table-responsive">
    <table width="100%">
        <tr>
            <td width="80%">
                    <a class="btn btn-sm btn-danger" href="<?php echo e(route('home')); ?>""><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
            </td>
            <td width="20%" align="right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('procedimiento.create')): ?>
                    <a class="btn btn-sm btn-success" data-toggle="modal" data-target="#modalProcedimiento" style="color: black"><i class="fas fa-clipboard-list"></i> Registrar Procedimiento</a>
                <?php endif; ?>
            </td>
        </tr>
    </table>
</div>
<br/>
<br/>
<div class="pull-bottom">
    <div class="table table-responsive">
        <table id="example" class="display" style="width:100%;color: black">
            <thead>
                <tr>
                    <th style="color: black">Nombre</th>
                    <th style="color: black">Acciones</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($datos->nombre); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('procedimiento.show')): ?>
                                <a class="btn btn-info btn-circle" data-toggle="modal" data-target="#modalEditProcedimiento" 
                                onclick="selectProcedimiento(<?php echo e($datos->id); ?>,'<?php echo e($datos->nombre); ?>','<?php echo e($datos->descripcion); ?>',0);" title="Detalles del Procedimiento"><i class="fas fa-eye" style="color: white"></i></a> 
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('procedimiento.edit')): ?>
                                <a class="btn btn-primary btn-circle" data-toggle="modal" data-target="#modalEditProcedimiento" 
                                onclick="selectProcedimiento(<?php echo e($datos->id); ?>,'<?php echo e($datos->nombre); ?>','<?php echo e($datos->descripcion); ?>');" title="Editar Procedimiento"><i class="fas fa-pencil-alt" style="color: white"></i></a> 
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('procedimiento.destroy')): ?>
                                <button type="button" class="btn btn-danger btn-circle" data-toggle="modal" data-target="#modal-default<?php echo e($datos->id); ?>">
                                    <i class="fas  fa-trash-alt"></i>
                                </button>
                                <div class="modal fade" id="modal-default<?php echo e($datos->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4>Eliminar Procedimiento</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            </div>
                                            <form action="<?php echo e(route('procedimientos.destroy',['procedimiento' => $datos->id])); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="_method" value="DELETE">
                                                <div class="modal-body">
                                                    <h4>Realmente desea eliminar el procedimiento: <strong><?php echo e($datos->nombre); ?></strong>?</h4>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-sm btn-secondary pull-left" data-dismiss="modal">Cerrar</button>
                                                    <button type="submit" class="btn btn-sm btn-danger">Si</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<!-- Modal para editar de procedimiento -->
<div class="modal fade bd-example-modal-lg" id="modalEditProcedimiento" tabindex="-1" role="dialog" aria-labelledby="modalProcedimientoLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalProcedimientoLabel"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form id="formularioEdicion" role="form" method="POST" action="" autocomplete="off">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <?php echo e(method_field('PUT')); ?>

                    <div class="form-group row <?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                        <label for="nombre_edit" class="col-sm-4 col-form-label">Nombre del Procedimiento:<font color="red">*</font></label>
                        <div class="col-sm-8">
                            <input id="nombre_edit" type="text" class="form-control" name= "nombre" value="<?php echo e(old('nombre')); ?>" required>
                            <?php if($errors->has('nombre')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('nombre')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row <?php echo e($errors->has('descripcion') ? ' has-error' : ''); ?>">
                        <label for="descripcion_edit" class="col-sm-4 col-form-label">Descripción:<font color="red">*</font></label>
                        <div class="col-sm-8">
                            <textarea id="descripcion_edit" name= "descripcion" class="form-control" rows="5" required><?php echo e(old('descripcion')); ?></textarea>
                            <?php if($errors->has('descripcion')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                </div>
            </form>
        </div>
    </div>
</div>

<!-- Modal para registro de procedimiento -->
<div class="modal fade bd-example-modal-lg" id="modalProcedimiento" tabindex="-1" role="dialog" aria-labelledby="modalProcedimientoLabell" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalProcedimientoLabell">Registrar Procedimiento</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form method="POST" action="<?php echo e(route('procedimientos.store')); ?>" autocomplete="off">
                <div class="modal-body">
                    <?php echo csrf_field(); ?>
                    <div class="form-group row <?php echo e($errors->has('nombre') ? ' has-error' : ''); ?>">
                        <label for="nombre" class="col-sm-4 col-form-label">Nombre del Procedimiento:<font color="red">*</font></label>
                        <div class="col-sm-8">
                            <input id="nombre" type="text" class="form-control" name= "nombre" value="<?php echo e(old('nombre')); ?>" required>
                            <?php if($errors->has('nombre')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('nombre')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group row <?php echo e($errors->has('descripcion') ? ' has-error' : ''); ?>">
                        <label for="descripcion" class="col-sm-4 col-form-label">Descripción:<font color="red">*</font></label>
                        <div class="col-sm-8">
                            <textarea id="descripcion" name= "descripcion" class="form-control" rows="5" required><?php echo e(old('descripcion')); ?></textarea>
                            <?php if($errors->has('descripcion')): ?>
                                <span class="help-block">
                                    <strong><?php echo e($errors->first('descripcion')); ?></strong>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
                    <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script src="<?php echo e(asset('js/modales/modalEditarProcedimiento.js')); ?>"></script>
<script type="text/javascript">
    $(document).ready( function () {
        $('#example').DataTable({
            "language": {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
                },
            responsive:true,
            pagingType:'simple',
            "columnDefs": [
                { "orderable": false, "targets": 1 }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/procedimientos/index.blade.php ENDPATH**/ ?>