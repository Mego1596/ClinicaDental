<?php $__env->startSection('titulo'); ?>
    Editar Rol
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<h1 style="text-align: center;"><strong>Editar Rol</strong></h1>
<?php if(count($errors) > 0): ?>
	<div class="alert alert-danger" role="alert">
		<ul>
			<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<li><?php echo e($error); ?></li>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</ul>
	</div>
<?php endif; ?>
<?php if(session()->has('danger')): ?>
	<div class="alert alert-danger" role="alert"><?php echo e(session('danger')); ?></div>
<?php endif; ?>
<form role="form" action="<?php echo e(route('roles.update',['role' => $rol->id])); ?>" autocomplete="off" method="POST">
  	<?php echo e(csrf_field()); ?>

  	<?php echo e(method_field('PUT')); ?>

  	<div class="form-group">
      <label for="name">Nombre del Rol:</label>
      <input type="text" class="form-control" id="name" name="name" placeholder="Nombre del Rol" required value="<?php echo e($rol->name); ?>">
    </div>
    <div class="form-group">
      <label for="slug">Identificador:</label>
      <input type="text" class="form-control" id="slug" name="slug" placeholder="Identificador" required value="<?php echo e($rol->slug); ?>">
    </div>

    <div class="form-group">
      <label for="description">Descripcion:</label>
      <input type="text" class="form-control" id="description" name="description" placeholder="Descripcion" required value="<?php echo e($rol->description); ?>">
    </div>
    <?php if($rol->id != 1 && $rol->id != 2): ?>
	    <div class="form-group">
	    	<nav>
				<div class="nav nav-tabs" id="nav-tab" role="tablist">
					<?php
						$tableAnterior 		= 	"";
						$section 			=	[];
					?>
					<?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				      	<?php
				      		$table 			= 	explode(".",$permiso->slug);
				      	 	$table 			= 	$table[0];

				      	?>
				      	<?php if($table != $tableAnterior): ?>
				      		<?php if($loop->first): ?>
				      			<a class="nav-item nav-link active" id="nav-<?php echo e($table); ?>-tab" data-toggle="tab" href="#nav-<?php echo e($table); ?>" role="tab" aria-controls="nav-<?php echo e($table); ?>" aria-selected="true"><?php echo e($table); ?></a>
				      		<?php else: ?>
				      			<a class="nav-item nav-link" id="nav-<?php echo e($table); ?>-tab" data-toggle="tab" href="#nav-<?php echo e($table); ?>" role="tab" aria-controls="nav-<?php echo e($table); ?>" aria-selected="false"><?php echo e($table); ?></a>
				      		<?php endif; ?>
				      	<?php 
				      		$tableAnterior = $table;
				      		$section[] = $table;
				      	?>
				      	<?php endif; ?>
				    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</div>
			</nav>
			<div class="tab-content" id="nav-tabContent">
				<?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sec): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($loop->first): ?>
						<div class="tab-pane fade show active" id="nav-<?php echo e($sec); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e($sec); ?>-tab">
							<div class="container">
								<fieldset class="form-group">
								    <div class="row">
								      <legend class="col-form-label col-sm-2 pt-0">Permisos</legend>
								      	<div class="col-sm-10">
									      	<?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($sec == explode(".",$permiso->slug)[0]): ?>
													<?php if(in_array($permiso->slug,$slugs)): ?>
												        <div class="form-check">
												        	<label class="form-check-label">
												          		<input type="checkbox" name="permission[]" value="<?php echo e($permiso->id); ?>" checked>
												            	<?php echo e($permiso->description); ?>

												          	</label>
												        </div>
											        <?php else: ?>
											        	<div class="form-check">
												        	<label class="form-check-label">
												          		<input type="checkbox" name="permission[]" value="<?php echo e($permiso->id); ?>">
												            	<?php echo e($permiso->description); ?>

												          	</label>
												        </div>
											        <?php endif; ?>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								      	</div>
								    </div>
								  </fieldset>												
							</div>
						</div>
					<?php else: ?>
						<div class="tab-pane fade" id="nav-<?php echo e($sec); ?>" role="tabpanel" aria-labelledby="nav-<?php echo e($sec); ?>-tab">
							<div class="container">
								<fieldset class="form-group">
								    <div class="row">
								      <legend class="col-form-label col-sm-2 pt-0">Permisos</legend>
								      	<div class="col-sm-10">
									      	<?php $__currentLoopData = $permisos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permiso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($sec == explode(".",$permiso->slug)[0]): ?>
											        <?php if(in_array($permiso->slug, $slugs)): ?>
												        <div class="form-check">
												        	<label class="form-check-label">
												          		<input type="checkbox" name="permission[]" value="<?php echo e($permiso->id); ?>" checked>
												            	<?php echo e($permiso->description); ?>

												          	</label>
												        </div>
											        <?php else: ?>
											        	<div class="form-check">
												        	<label class="form-check-label">
												          		<input type="checkbox" name="permission[]" value="<?php echo e($permiso->id); ?>">
												            	<?php echo e($permiso->description); ?>

												          	</label>
												        </div>
											        <?php endif; ?>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								      	</div>
								    </div>
								  </fieldset>												
							</div>
						</div>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
	    </div>
   	<?php else: ?>
   		<div class="form-group" align="center">
   			<?php if($rol->id == 1): ?>
   				<h1>Acceso Total</h1>
   			<?php elseif($rol->id == 2): ?>
   				<h1>Sin Acceso</h1>
   			<?php endif; ?>
   		</div>
   	<?php endif; ?>
	<div class="d-flex justify-content-center">
		<button class="btn btn-sm btn-success" style="margin-right: 1%"><i class="fa fa-save"></i> Guardar</button>
		<a href="<?php echo e(route('roles.index')); ?>" class="btn btn-sm btn-danger" style=""><i class="fas fa-arrow-circle-left"></i> Regresar</a>
	</div>
</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/roles/edit_rol.blade.php ENDPATH**/ ?>