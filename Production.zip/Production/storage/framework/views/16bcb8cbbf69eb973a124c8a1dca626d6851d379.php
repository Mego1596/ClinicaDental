<?php $__env->startSection('titulo'); ?>
	Receta
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1 style="text-align: center;"><strong>Receta</strong></h1>
	<?php if(\Session::has('success')): ?>
	    <div class="alert alert-success">
	        <ul>
	            <li><?php echo \Session::get('success'); ?></li>
	        </ul>
	    </div>
	<?php endif; ?>
	<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger" role="alert">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	<?php endif; ?>
	<?php if(session()->has('danger')): ?>
		<div class="alert alert-danger" role="alert"><?php echo e(session('danger')); ?></div>
	<?php endif; ?>
    <?php if(isset($cita->receta)): ?>
	    <div class="table-responsive">
			<table width="100%">
				<tr>
					<td width="30%">
					        <a class="btn btn-sm btn-danger" href="<?php echo e(route('home')); ?>""><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
					</td>
					<td width="40%" align="center">
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.show')): ?>
							<a class="btn btn-sm btn-info" href="<?php echo e(route('citas.recetas.show',['receta' => $cita->receta->id,'cita'=>$cita->id])); ?>" target="_blank">
				        		<i class="fas fa-file-pdf"></i> Generar PDF
				        	</a>
				        <?php endif; ?>
					</td>
					<?php if(sizeof($cita->receta->detalle_receta) < 2): ?>
						<td width="10%" align="right">
					        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.create')): ?>
					            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#crearRecetaDetalle">
						        	<i class="fas fa-fw fa-clipboard-list"></i> Asignar Detalles
						        </button>
								<!-- Modal -->
								<div class="modal fade" id="crearRecetaDetalle" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
									<div class="modal-dialog modal-md" role="document">
										<div class="modal-content">
											<div class="modal-header">
												<h5 class="modal-title" id="exampleModalLabel">Asignar Detalles de Receta</h5>
												<button type="button" class="close" data-dismiss="modal" aria-label="Close">
													<span aria-hidden="true">&times;</span>
												</button>
											</div>
											<form method="POST" autocomplete="off" action="<?php echo e(route('recetas.detalles.store',['receta' => $cita->receta->id])); ?>">
												<?php echo csrf_field(); ?>
												<div class="modal-body">
													<div class="form-group row">
													    <label for="medicamento" class="col-sm-6 col-form-label">Medicamento:</label>
													    <div class="col-sm-6">
												            <input id="medicamento" type='text' class="form-control" name="medicamento" value="<?php echo e(old('medicamento')); ?>" required />
													    </div>
													</div>
													<div class="form-group row">
													    <label for="dosis" class="col-sm-6 col-form-label">Dosis:</label>
													    <div class="col-sm-6">
												            <input id="dosis" type='text' class="form-control" name="dosis" value="<?php echo e(old('dosis')); ?>" required/>
													    </div>
													</div>
													<div class="form-group row">
													    <label for="cantidad" class="col-sm-6 col-form-label">Cantidad:</label>
													    <div class="col-sm-6">
												            <input id="cantidad" type='text' class="form-control" name="cantidad" value="<?php echo e(old('cantidad')); ?>" required/>
													    </div>
													</div>
												</div>
												<div class="modal-footer">
													<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
													<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
												</div>	
											</form>
										</div>
									</div>
								</div>
					        <?php endif; ?>
						</td>
						<td width="10%" align="right">
							<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.edit')): ?>
								<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#editarReceta">
						        	<i class="fa fa-pencil"></i> Editar Receta
						        </button>
						    <?php endif; ?>
					    </td>
					    <td width="10%" align="right">
					    	<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.destroy')): ?>
						        <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modal-default-eliminar-receta">
						        	<i class="fas fa-trash-alt"></i> Eliminar Receta
						        </button>
					       	<?php endif; ?>
						</td>
					<?php else: ?>
						<td width="21%" align="right">
							<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.edit')): ?>
								<button type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#editarReceta">
						        	<i class="fa fa-pencil"></i> Editar Receta
						        </button>
						    <?php endif; ?>
					    </td>
					    <td width="9%" align="right">
					        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.destroy')): ?>
						        <button type="button" class="btn btn-sm btn-danger" data-toggle="modal" data-target="#modal-default-eliminar-receta">
						        	<i class="fas fa-trash-alt"></i> Eliminar Receta
						        </button>
					       	<?php endif; ?>
						</td>
					<?php endif; ?>
					<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.edit')): ?>
						<!-- Modal para editar de detalles de receta -->
						<div class="modal fade bd-example-modal-md" id="modalEditDetalle" tabindex="-1" role="dialog" aria-labelledby="modalDetalleLabel" aria-hidden="true">
						    <div class="modal-dialog modal-md" role="document">
						        <div class="modal-content">
						            <div class="modal-header">
						                <h5 class="modal-title" id="modalDetalleLabel">Editar detalle de la receta</h5>
						                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
						                    <span aria-hidden="true">&times;</span>
						                </button>
						            </div>
						            <form id="formularioEdicion" role="form" method="POST" action="" autocomplete="off">
						                <div class="modal-body">
						                    <?php echo csrf_field(); ?>
						                    <?php echo e(method_field('PUT')); ?>

						                    <div class="form-group row <?php echo e($errors->has('medicamento') ? ' has-error' : ''); ?>">
						                        <label for="medicamento_edit" class="col-sm-4 col-form-label">Medicamento:</label>
						                        <div class="col-sm-8">
						                            <input id="medicamento_edit" type="text" class="form-control" name= "medicamento" required>
						                            <?php if($errors->has('medicamento')): ?>
						                                <span class="help-block">
						                                    <strong><?php echo e($errors->first('medicamento')); ?></strong>
						                                </span>
						                            <?php endif; ?>
						                        </div>
						                    </div>
						                    <div class="form-group row <?php echo e($errors->has('dosis') ? ' has-error' : ''); ?>">
						                        <label for="dosis_edit" class="col-sm-4 col-form-label">Dosis:</label>
						                        <div class="col-sm-8">
						                            <input id="dosis_edit" type="text" name="dosis" class="form-control" required/>
						                            <?php if($errors->has('dosis')): ?>
						                                <span class="help-block">
						                                    <strong><?php echo e($errors->first('dosis')); ?></strong>
						                                </span>
						                            <?php endif; ?>
						                        </div>
						                    </div>
						                    <div class="form-group row <?php echo e($errors->has('cantidad') ? ' has-error' : ''); ?>">
						                        <label for="cantidad_edit" class="col-sm-4 col-form-label">Cantidad:</label>
						                        <div class="col-sm-8">
						                            <input id="cantidad_edit" type="text" name= "cantidad" class="form-control" required/>
						                            <?php if($errors->has('cantidad')): ?>
						                                <span class="help-block">
						                                    <strong><?php echo e($errors->first('cantidad')); ?></strong>
						                                </span>
						                            <?php endif; ?>
						                        </div>
						                    </div>
						                </div>
						                <div class="modal-footer">
						                	<button type="button" class="btn btn-secondary" data-dismiss="modal">Cancelar</button>
						                	<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
						                </div>
						            </form>
						        </div>
						    </div>
						</div>
						<!-- Modal -->
						<div class="modal fade bd-example-modal-md" id="editarReceta" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog modal-md" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">Editar Receta</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<form method="POST" autocomplete="off" action="<?php echo e(route('citas.recetas.update',['cita' => $cita->id,'receta' => $cita->receta->id])); ?>">
										<?php echo csrf_field(); ?>
										<?php echo e(method_field('PUT')); ?>

										<div class="modal-body">
											<div class="form-group row">
											    <label for="peso_form" class="col-sm-6 col-form-label">Peso:</label>
											    <div class="col-sm-6">
										            <input id="peso_form" type='number' step="0.10" class="form-control" name="peso" value="<?php echo e($cita->receta->peso); ?>" required />
											    </div>
											</div>
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
											<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
										</div>	
									</form>
								</div>
							</div>
						</div>
			        <?php endif; ?>
			        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.destroy')): ?>
                        <!-- Modal -->
						<div class="modal fade bd-example-modal-md" id="modal-default-eliminar-receta" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
							<div class="modal-dialog modal-md" role="document">
								<div class="modal-content">
									<div class="modal-header">
										<h5 class="modal-title" id="exampleModalLabel">Eliminar receta</h5>
										<button type="button" class="close" data-dismiss="modal" aria-label="Close">
											<span aria-hidden="true">&times;</span>
										</button>
									</div>
									<form method="POST" autocomplete="off" action="<?php echo e(route('citas.recetas.destroy',['cita'=>$cita->id,'receta' => $cita->receta->id])); ?>">
										<?php echo csrf_field(); ?>
										<?php echo e(method_field('DELETE')); ?>

										<div class="modal-body">
											Realmente desea eliminar la receta?
										</div>
										<div class="modal-footer">
											<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
											<button type="submit" class="btn btn-danger"> Si</button>
										</div>	
									</form>
								</div>
							</div>
						</div>
                    <?php endif; ?>
				</tr>
			</table>
		</div>
		<?php
			$date=date_create($cita->receta->create_at);
			$aux= date_format($date,"d/m/Y");
		?>
		<h1 style="text-align: center;"><strong><?php echo e($aux); ?></strong></h1>
		<hr>
		<div class="row">
			<div class="col-md-12">
				<div class="form-group row col-sm-12">
					<label for="nombre" class="col-sm-2 col-form-label">Nombre Completo:</label>
					<div class="col-sm-4">
						<input type="text" class="form-control" id="nombre" value="<?php echo e($cita->persona->primer_nombre.' '.$cita->persona->segundo_nombre.' '.$cita->persona->primer_apellido.' '.$cita->persona->segundo_apellido); ?>" readonly disabled>
					</div>
					<label for="peso" class="col-sm-2 col-form-label">Peso:</label>
					<div class="col-sm-4">
						<input type="text" class="form-control" id="peso" value="<?php echo e($cita->receta->peso); ?>" readonly disabled>
					</div>
				</div>	
				<div class="table-responsive">
					<table class="display table-hovered table-striped" width="100%">
						<tr>
							<th>Medicamento</th>
							<th>Dosis</th>
							<th>Cantidad</th>
							<th>Acciones</th>
						</tr>
						<?php if(sizeof($cita->receta->detalle_receta) != 0): ?>
							<?php $__currentLoopData = $cita->receta->detalle_receta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detalle): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td width="25%"><?php echo e($detalle->medicamento); ?></td>
									<td width="25%"><?php echo e($detalle->dosis); ?></td>
									<td width="25%"><?php echo e($detalle->cantidad); ?></td>
									<td width="25%">
										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.edit')): ?>
											<button type="button" class="btn btn-outline-primary" data-toggle="modal" data-target="#modalEditDetalle" onclick="selectDetalle(<?php echo e($cita->receta->id); ?>,<?php echo e($detalle->id); ?>,'<?php echo e($detalle->medicamento); ?>','<?php echo e($detalle->dosis); ?>','<?php echo e($detalle->cantidad); ?>');" title="Detalles de la receta"><i class="fa fa-pencil"></i> Editar</button>
										<?php endif; ?>
										<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.destroy')): ?>
		    	                            <button type="button" class="btn btn-outline-danger" data-toggle="modal" data-target="#modal-default-<?php echo e($detalle->id); ?>">
		    	                                <i class="fas fa-fw fa-trash-alt"></i> Eliminar
		    	                            </button>

			    	                        <!-- Modal -->
											<div class="modal fade bd-example-modal-md" id="modal-default-<?php echo e($detalle->id); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
												<div class="modal-dialog modal-md" role="document">
													<div class="modal-content">
														<div class="modal-header">
															<h5 class="modal-title" id="exampleModalLabel">Eliminar detalle de receta</h5>
															<button type="button" class="close" data-dismiss="modal" aria-label="Close">
																<span aria-hidden="true">&times;</span>
															</button>
														</div>
														<form method="POST" autocomplete="off" action="<?php echo e(route('recetas.detalles.destroy',['receta'=>$cita->receta->id,'detalles' => $detalle->id])); ?>">
															<?php echo csrf_field(); ?>
															<?php echo e(method_field('DELETE')); ?>

															<div class="modal-body">
																Realmente desea eliminar el medicamento:<strong><?php echo e($detalle->medicamento); ?></strong>
															</div>
															<div class="modal-footer">
																<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
																<button type="submit" class="btn btn-danger"> Si</button>
															</div>	
														</form>
													</div>
												</div>
											</div>
		    	                        <?php endif; ?>
									</td>
								</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						<?php endif; ?>
					</table>
				</div>							
			</div>
		</div>
	<?php else: ?>
		<div class="table-responsive">
			<table width="100%">
				<tr>
					<td width="80%">
					        <a class="btn btn-sm btn-danger" href="<?php echo e(route('home')); ?>""><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
					</td>
					<td width="20%" align="right">
				        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('receta.create')): ?>
				            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#crearReceta" style="color: black">
					        	<i class="fas fa-fw fa-clipboard-list"></i> Registrar Receta
					        </button>
				        <?php endif; ?>
					</td>
				</tr>
			</table>
		</div>
		<!-- Modal -->
		<div class="modal fade" id="crearReceta" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-md" role="document">
				<div class="modal-content">
					<div class="modal-header">
						<h5 class="modal-title" id="exampleModalLabel">Registrar Receta</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<form method="POST" autocomplete="off" action="<?php echo e(route('citas.recetas.store',['cita' => $cita->id])); ?>">
						<?php echo csrf_field(); ?>
						<div class="modal-body">
							<div class="form-group row">
							    <label for="peso_form" class="col-sm-6 col-form-label">Peso:</label>
							    <div class="col-sm-6">
						            <input id="peso_form" type='number' step="0.10" class="form-control" name="peso" value="<?php echo e(old('peso')); ?>" required />
							    </div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
							<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
						</div>	
					</form>
				</div>
			</div>
		</div>
	<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS'); ?>
<script src="<?php echo e(asset('js/modales/GestionReceta.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/recetas/index.blade.php ENDPATH**/ ?>