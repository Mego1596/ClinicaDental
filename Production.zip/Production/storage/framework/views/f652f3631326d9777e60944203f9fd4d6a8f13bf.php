<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Usuario y contraseña</title>
</head>
<body>
    <h2>Usuario y contraseña</h2>
    <h2>Bienvenido a clinica <?php echo $__env->make('layouts.nombreEmpresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </h2>
    <p>
        Usuario: <?php echo e($user->name); ?> <br>
        Contraseña: <?php echo e($password); ?><br>
    </p>
    <strong> Almacene la clave en un lugar seguro </strong>
    <br>
    <cite>Saludos, clinica <?php echo $__env->make('layouts.nombreEmpresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </cite>
</body>
</html><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/email/user.blade.php ENDPATH**/ ?>