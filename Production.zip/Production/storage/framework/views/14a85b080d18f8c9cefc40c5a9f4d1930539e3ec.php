<?php $__env->startSection('titulo'); ?>
    Lista de Roles
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('danger')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('danger'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<div class="panel-title">
    <h1 align="center" style="color: black">Lista de Roles</h1>
</div>
<div class="table-responsive">
    <table width="100%">
        <tr>
            <td width="80%">
                    <a class="btn btn-sm btn-danger" href="<?php echo e(route('home')); ?>""><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
            </td>
            <td width="20%" align="right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.create')): ?>
                    <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-sm btn-success"  style="color: black"><i class="fas fa-fw fa-clipboard-list"></i> Registrar Rol</a>
                <?php endif; ?>
            </td>
        </tr>
    </table>
</div>
<br/>
<br/>
<div class="pull-bottom">
    <div class="table table-responsive table-striped">
        <table id="example" class="display" style="width:100%;color: black">
            <thead>
                <tr>
                    <th style="color: black">Rol</th>
                    <th style="color: black">Descripción</th>
                    <th style="color: black">Identificador</th>
                    <th style="color: black">Acciones</th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rol): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($rol->name); ?></td>
                        <td><?php echo e($rol->description); ?></td>
                        <td><?php echo e($rol->slug); ?></td>
                        <td>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.show')): ?>
                                <a href="<?php echo e(route('roles.show',['role' => $rol->id])); ?>" class="btn btn-info btn-circle" title="Ver perfil" ><i class="fas fa-eye"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.edit')): ?>
                                <a class="btn btn-primary btn-circle" href="<?php echo e(route('roles.edit', ['role' => $rol->id])); ?>"><i class="fas fa-fw fa-pencil-alt"></i></a>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('role.destroy')): ?>
                                <button type="button" class="btn btn-danger btn-circle" data-toggle="modal" data-target="#modal-default2<?php echo e($rol->id); ?>">
                                    <i class="fas fa-fw fa-trash-alt"></i>
                                </button>
                                <div class="modal fade" id="modal-default2<?php echo e($rol->id); ?>">
                                    <div class="modal-dialog">
                                        <div class="modal-content">
                                            <div class="modal-header">
                                                <h4>Eliminar Rol</h4>
                                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span></button>
                                            </div>
                                            <form action="<?php echo e(route('roles.destroy',['role' => $rol->id])); ?>" method="POST">
                                                <?php echo e(csrf_field()); ?>

                                                <input type="hidden" name="_method" value="DELETE">
                                                <div class="modal-body">
                                                    <h4>Realmente desea eliminar el rol: <strong><?php echo e($rol->name); ?></strong>?</h4>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-sm btn-secondary pull-left" data-dismiss="modal">Cerrar</button>
                                                    <button type="submit" class="btn btn-sm btn-danger">Si</button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script type="text/javascript">
    $(function () {
        $('#example').DataTable({
            "language": {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
                },
            responsive:true,
            pagingType: "simple",
            "columnDefs": [
                { "orderable": false, "targets": 3 }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/roles/index.blade.php ENDPATH**/ ?>