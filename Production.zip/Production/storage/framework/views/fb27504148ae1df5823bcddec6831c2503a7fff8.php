<!DOCTYPE html>
<html>
<head>
    <title>Iniciar Sesión</title>

    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/login.css')); ?>">
    <link rel="stylesheet" href="//maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css">

</head>
<body>
    <div class="main">
        <div class="container">
            <center>
                <div class="middle">
                    <div id="login">
                        <?php if(session()->has('danger')): ?>
                        <div style="background-color: red;width: 100%;color: white"><?php echo e(session('danger')); ?></div>
                        <br/>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <p><span class="fa fa-user"></span><input id="name" type="text" class="form-control <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="name" value="<?php echo e(old('name')); ?>" required autocomplete="off" autofocus Placeholder="Usuario"></p>
                                    <?php if ($errors->has('name')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('name'); ?>
                                        <div class="alert alert-danger" role="alert" style="background-color: #f8d7da;margin-bottom: 1%">
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <div class="col-md-6">
                                    <p><span class="fa fa-lock"></span><input id="password" type="password" class="form-control <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?> is-invalid <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>" name="password" required autocomplete="current-password" Placeholder="Password">
                                    </p>
                                    <?php if ($errors->has('password')) :
if (isset($message)) { $messageCache = $message; }
$message = $errors->first('password'); ?>
                                        <div class="alert alert-danger" style="background-color: #f8d7da">
                                            <span class="invalid-feedback" role="alert">
                                                <strong><?php echo e($message); ?></strong>
                                            </span>
                                        </div>
                                    <?php unset($message);
if (isset($messageCache)) { $message = $messageCache; }
endif; ?>
                                </div>
                            </div>
                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4" style="font-size: 14px">
                                    <?php if(Route::has('password.request')): ?>
                                        <a style="width:48%; text-align:left;  display: inline-block;" class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                            <?php echo e(__('Olvide mi Constraseña')); ?>

                                        </a>
                                    <?php endif; ?>
                                    <span style="width:50%; text-align:right;  display: inline-block;"><input type="submit" value="Iniciar Sesión" class="btn btn-primary"></span>
                                    
                                </div>
                            </div>
                        </form>
                        <div class="clearfix"></div>
                    </div> <!-- end login -->
                    <div class="logo"><a href="/"><?php echo $__env->make('layouts.nombreEmpresa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></a>
                      <div class="clearfix"></div>
                    </div> 
                </div>
            </center>
        </div>
    </div>
</body>
</html><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/auth/login.blade.php ENDPATH**/ ?>