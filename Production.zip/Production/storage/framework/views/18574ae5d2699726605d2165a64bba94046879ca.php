<?php $__env->startSection('titulo'); ?>
	Inicio
<?php $__env->stopSection(); ?>
<?php $__env->startSection('CSS'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.css"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <?php echo $calendar->calendar(); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('JS'); ?>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.9.0/fullcalendar.js"></script>
    <?php echo $calendar->script(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/citas/index.blade.php ENDPATH**/ ?>