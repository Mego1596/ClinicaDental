<?php $__env->startSection('titulo'); ?>
	Pago
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
	<h1 style="text-align: center;"><strong>Pago</strong></h1>
	<?php if(\Session::has('success')): ?>
	    <div class="alert alert-success">
	        <ul>
	            <li><?php echo \Session::get('success'); ?></li>
	        </ul>
	    </div>
	<?php endif; ?>
	<?php if(count($errors) > 0): ?>
		<div class="alert alert-danger" role="alert">
			<ul>
				<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><?php echo e($error); ?></li>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</ul>
		</div>
	<?php endif; ?>
	<?php if(session()->has('danger')): ?>
		<div class="alert alert-danger" role="alert"><?php echo e(session('danger')); ?></div>
	<?php endif; ?>

	<?php if(isset($cita->pago)): ?>
		<div class="table-responsive">
			<table width="100%">
				<tr>
					<td width="70%">
					    <a class="btn btn-sm btn-danger" href="<?php echo e(route('home')); ?>""><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
					</td>
					<td width="30%" align="right">
						<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pago.edit')): ?>
				            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#modal-default-editar-pago">
					        	<i class="fa fa-pencil"></i> Editar 
					        </button>
				        <?php endif; ?>
					</td>
				</tr>
			</table>
		</div>
		<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pago.edit')): ?>
			<!-- Modal -->
			<div class="modal fade bd-example-modal-md" id="modal-default-editar-pago" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
				<div class="modal-dialog modal-md" role="document">
					<div class="modal-content">
						<div class="modal-header">
							<h5 class="modal-title" id="exampleModalLabel">Editar Pago</h5>
							<button type="button" class="close" data-dismiss="modal" aria-label="Close">
								<span aria-hidden="true">&times;</span>
							</button>
						</div>
						<form method="POST" autocomplete="off" action="<?php echo e(route('citas.pagos.update',['cita' => $cita->id,'pago' => $cita->pago->id])); ?>">
							<?php echo csrf_field(); ?>
							<?php echo e(method_field('PUT')); ?>

							<div class="modal-body">
								<div class="form-group row">
									<input type="hidden" name="total_plan" class="form-control" id="total_plan_edit" value="<?php echo e($total); ?>" required>
								    <label for="abono_edit" class="col-sm-6 col-form-label">Abono:</label>
								    <div class="col-sm-6">
								      	<input type="number" step="0.01" min="0" name="abono" class="form-control" id="abono_edit" value="<?php echo e($cita->pago->abono); ?>" required>
								    </div>
								</div>
								<div class="form-group row">
								    <label for="user" class="col-sm-6 col-form-label">Doctor Asignado:</label>
								    <div class="col-sm-6">
								    	<select id="user" name="user" class="form-control" required>
								    		<option value="">Seleccione el doctor</option>
								    		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								    			<?php if($cita->pago->user_id == $user->id): ?>
								    				<option value="<?php echo e($user->id); ?>" selected>Dr.<?php echo e($user->primer_nombre.' '.$user->segundo_nombre.' '.$user->primer_apellido.' '.$user->segundo_apellido); ?></option>
								    			<?php else: ?>
								    				<option value="<?php echo e($user->id); ?>">Dr.<?php echo e($user->primer_nombre.' '.$user->segundo_nombre.' '.$user->primer_apellido.' '.$user->segundo_apellido); ?></option>
								    			<?php endif; ?>
								    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								    	</select>
								    </div>
								</div>
							</div>
							<div class="modal-footer">
								<button type="button" class="btn btn-secondary" data-dismiss="modal">Cerrar</button>
								<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
							</div>	
						</form>
					</div>
				</div>
			</div>
        <?php endif; ?>
    	<div class="table-responsive">
			<table class="display table-hovered table-striped" width="100%">
				<tr>
					<th>Fecha</th>
					<th>Realizo el tratamiento</th>
					<th>Abono</th>
				</tr>
				<tr>
					<td width="25%"><?php echo e($cita->pago->created_at); ?></td>
					<td width="25%">Dr. <?php echo e($cita->pago->user->persona->primer_nombre." ".$cita->pago->user->persona->segundo_nombre." ".$cita->pago->user->persona->primer_apellido." ".$cita->pago->user->persona->segundo_apellido); ?></td>
					<td width="25%"><?php echo e($cita->pago->abono); ?></td>
				</tr>
			</table>
		</div>
	<?php else: ?>
		<div class="table-responsive">
			<table width="100%">
				<tr>
					<td width="80%">
					       <a class="btn btn-sm btn-danger" href="<?php echo e(route('home')); ?>""><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
					</td>
					<td width="20%" align="right">
				        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('pago.create')): ?>
				            <button type="button" class="btn btn-sm btn-success" data-toggle="modal" data-target="#crearPago" style="color: black">
					        	<i class="fas fa-hand-holding-usd"> <font size="1px"><i class="fa fa-plus"></i></i></font> Registrar Pago
					        </button>
				        <?php endif; ?>
					</td>
				</tr>
			</table>
		</div>

		<!-- Modal -->
		<div class="modal fade" id="crearPago" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
			<div class="modal-dialog modal-lg" role="document">
				<div class="modal-content">
					<div class="modal-header">
					<h5 class="modal-title" id="exampleModalLabel">Crear Pago</h5>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close">
							<span aria-hidden="true">&times;</span>
						</button>
					</div>
					<form autocomplete="off" method="POST" action="<?php echo e(route('citas.pagos.store',['cita' => $cita->id])); ?>">
						<?php echo csrf_field(); ?>
						<div class="modal-body">

							<input type="hidden" name="total_plan" class="form-control" id="total_plan" value="<?php echo e($total); ?>" required>
	
							<div class="form-group row">
							    <label for="abono" class="col-sm-6 col-form-label">Abono:</label>
							    <div class="col-sm-6">
							      	<input type="number" step="0.01" min="0" name="abono" class="form-control" id="abono" value="<?php echo e(old('abono')); ?>" required>
							    </div>
							</div>
							<div class="form-group row">
							    <label for="user" class="col-sm-6 col-form-label">Doctor Asignado:</label>
							    <div class="col-sm-6">
							    	<select id="user" name="user" class="form-control" required>
							    		<option value="">Seleccione el doctor</option>
							    		<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							    			<option value="<?php echo e($user->id); ?>">Dr.<?php echo e($user->primer_nombre.' '.$user->segundo_nombre.' '.$user->primer_apellido.' '.$user->segundo_apellido); ?></option>
							    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							    	</select>
							    </div>
							</div>
						</div>
						<div class="modal-footer">
							<button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="far fa-times-circle"></i> Cerrar</button>
							<button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Guardar</button>
						</div>
					</form>
				</div>
			</div>
		</div>
	<?php endif; ?>
	<div class="d-flex justify-content-center">
		<table>
			<tr>
				<td>
					<h3>
						Total a pagar: <strong><?php echo e(round($total,2)); ?></strong>
					</h3>
				</td>
			</tr>
			<tr>
				<td align="center">
					<?php if($total == 0): ?>
						<p><h3>Solvente</h3></p>
					<?php endif; ?>
				</td>
			</tr>
		</table>
	</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script type="text/javascript">
	$(function(){
		$('#abono').attr('max',$('#total_plan').val())

		$('#crearPago').on('shown.bs.modal',function(e){
			$('#abono').val('');
		})
	})
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/pagos/index.blade.php ENDPATH**/ ?>