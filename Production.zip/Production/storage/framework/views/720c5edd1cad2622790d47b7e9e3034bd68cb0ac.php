<!DOCTYPE html>
<html>
<head>
    <title>Plan Tratamiento</title>
    <style type="text/css">
        .titulo{
            text-align: center;
            padding-bottom: -1rem;
            font-family: Arial, Helvetica, sans-serif;
            font-weight:bolder;
            font-size: 17px;
        }

        .titulo2{
            text-align: center;
            padding-bottom: -1rem;
            padding-top: -1rem;
        }

        .titulo3{
            text-align: center;
            font-family: Arial, Helvetica, sans-serif;
            font-weight:bolder;
            font-size: 15px;
            padding-bottom: -5rem;
            padding-top: .5rem;
        }

        .tabla-tra{
            margin-left: 19rem;
        }
        .separador{
            text-align: center;
        }

        .td-proc{

            border: 1px solid black;
            padding: 0em;
        }
        .alig{
            text-align: center;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-weight: bold;
            font-size: 15px;
        }
        .fuente{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size:14px;
        }

        .bordesB{
            border-left: 1px solid black;
            border-bottom: 1px solid black;
            border-top: 1px solid black;
        }
        .bordesA{
            border-right: 1px solid black;
            border-top: 1px solid black;
            border-bottom: 1px solid black;
        }

        table{
            border-spacing: none;
        }
        .alineado{
            text-align: center;
        }
        .firmas{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, Cantarell, 'Open Sans', 'Helvetica Neue', sans-serif;
            font-size: 13px;
        }
        .pac{
            padding-left: 5rem;
        }
        div.page_break{
        page-break-before: always;
        }
    </style>
    <style type="text/css">
        .tg2  {
            border-collapse:collapse;border-spacing:0;
        }
        .tg2 td{
            font-family:Arial, sans-serif;
            font-size:14px;
            padding:1px 5px;
            border-style:solid;
            border-width:1px;
            overflow:hidden;
            word-break:normal;
            border-color:black;
        }
        .tg2 th{
            font-family:Arial, sans-serif;
            font-size:14px;
            font-weight:normal;
            padding:1px 5px;
            border-style:solid;
            border-width:1px;
            overflow:hidden;
            word-break:normal;
            border-color:black;
        }
        .tg2 .tg-y9452{
            font-size:20px;
            font-family:"Arial Black", Gadget, sans-serif !important;
            border-color:#ffffff;
            text-align:center;
        }
        .tg2 .tg-dfg12{
            font-size:10px;
            border-color:#ffffff;
            text-align:center;
            vertical-align:top
        }
        .tg2 .tg-401l2{
            font-size:11px;
            border-color:#ffffff;
            text-align:center;
        }
        .tg2 .tg-ior22{
            font-size:11px;
            border-color:#ffffff;
            text-align:center;
            vertical-align:top
        }
    </style>
    <style type="text/css">
        .tg  {
            border-collapse:collapse;
            border-spacing:0;
            padding-left: .5rem;
        }
        .tg td{
            font-family:Arial, sans-serif;
            font-size:11px;
            padding:3px 5px;
            border-style:solid;
            border-width:1px;
            overflow:hidden;
            word-break:normal;
            border-color:black; 
            width: 400px;
        }
        .tg th{
            font-family:Arial, sans-serif;
            font-size:11px;
            font-weight:normal;
            padding:3px 5px;
            border-style:solid;
            border-width:1px;
            overflow:hidden;
            word-break:normal;
            border-color:black;
        }
        .tg .tg-s268{
            text-align:left
        }
        .tg .tg-0lax{
            text-align:left;
            vertical-align:top
        }
        .tg .bordes1{
            border-right: 1px solid white;
            border-left: 1px solid white;
            border-top: 1px solid white;
        }
        .tg .der{
            border-right: 1px solid white;
        }
    </style>
</head>
<body>
    <div>   
        <table class="tg2">
            <tr>
                <th class="tg-401l2" rowspan="2"><img src="img/titulo-yekixpaki.png" width="365" height="95"></th>
                <th class="tg-y9452"><span style="font-weight:bold">FICHA ODONTOLÓGICA</span></th>
            </tr>
            <tr>
                <td class="tg-401l2">Coronas, placas, puentes, rellenos, endodoncias, ortodoncias,<br>todo lo relacionado con Odontologia general, estetica e infantil.</td>
            </tr>
            <tr>
                <td class="tg-ior22" rowspan="2"><br>Col. Libertad, Av. Washington #414, San Salvador.<br>Telefono: 2102 - 2198</td>
                <td class="tg-ior22">De Lunes a miercoles, viernes y sabado de 2:00 pm a 6:00 pm</td>
            </tr>
            <tr>
                <td class="tg-dfg12"><span style="font-weight:bold">Telefono: (503) 6420-8735</span> - Domingos por cita</td>
            </tr>
        </table>
        <p class="titulo2">--------------------------------------------------------------------------------------------------------------------------------</p>
        <p class="titulo " style="font-weight:bold">DATOS DEL PACIENTE</p>
        
        <table class="tg" style="undefined;table-layout: fixed; width: 685px">
            <colgroup>
                <col style="width: 337px">
                <col style="width: 239px">
            </colgroup>
            <tr>
                <th class="tg-s268 bordes1">Fecha: <?php echo e($formato_fecha); ?>  </th>
                <th class="tg-0lax bordes1">Ficha#: <?php echo e($cita->id); ?> </th>
            </tr>
            <tr>
                <?php if(isset($cita->persona->user->email)): ?>
                    <td class="tg-0lax">E-mail: <?php echo e($cita->persona->user->email); ?></td>
                <?php else: ?>
                    <td class="tg-0lax">E-mail: </td>
                <?php endif; ?>
                <td class="tg-0lax">FC: <?php echo e($cita->persona->expediente->numero_expediente); ?></td>
            </tr>
            <tr>
                <td class="tg-0lax">Nombre: <?php echo e($cita->persona->primer_nombre." ".$cita->persona->segundo_nombre." ".$cita->persona->primer_apellido." ".$cita->persona->segundo_apellido); ?> </td>
                <td class="tg-0lax">Edad: <?php echo e($edad); ?> años</td>
            </tr>
            <tr>
                <td class="tg-0lax">Ocupacion: <?php echo e($cita->persona->expediente->ocupacion); ?></td>
                <td class="tg-0lax">Responsable: <?php echo e($cita->persona->expediente->responsable); ?></td>
            </tr>
            <tr>
                <td class="tg-0lax" colspan="2">Domicilio: <?php echo e($cita->persona->direccion); ?></td>
            </tr>
            <tr>
                <td class="tg-0lax der"></td>
                <td class="tg-0lax">Telefono: <?php echo e($cita->persona->telefono); ?></td>
            </tr>
            <tr>
                <td class="tg-0lax" colspan="2">Recomendado Por: <?php echo e($cita->persona->expediente->recomendado); ?></td>
            </tr>
            <tr>
                <td class="tg-0lax" colspan="2">Historia Odontologica Anterior:</td>
            </tr>
            <tr>
                <?php if(!is_null($cita->persona->expediente->historia_odontologica)): ?>
                    <td class="tg-0lax" colspan="2"><?php echo e($cita->persona->expediente->historia_odontologica); ?></td>
                <?php else: ?>
                    <td class="tg-0lax" colspan="2">
                        <br />
                    </td>
                <?php endif; ?>
            </tr>
            <tr>
                <td class="tg-0lax" colspan="2">Historia Medica Anterior:</td>
            </tr>
            <tr>
                <?php if(!is_null($cita->persona->expediente->historia_medica)): ?>
                    <td class="tg-0lax" colspan="2"><?php echo e($cita->persona->expediente->historia_medica); ?></td>
                <?php else: ?>
                    <td class="tg-0lax" colspan="2">
                        <br />
                    </td>
                <?php endif; ?>
            </tr>
        </table>
        <div align="center">
            <?php if(sizeof($ultimo_odontograma) == 1): ?>
                <div><h3>Inicial</h3></div>
                <div><img src="<?php echo e(public_path('img/odontograma.png')); ?>" width="700px" height="235px"></div>
                <div><h3>Actual</h3></div>
                <div><img src="<?php echo e($ultimo_odontograma[0]->odontograma); ?>"width="700px" height="235px"></div>
            <?php else: ?>
                <?php if(sizeof($ultimo_odontograma) == 2): ?>
                    <div><h3>Inicial</h3></div>
                    <div><img src="<?php echo e($ultimo_odontograma[1]->odontograma); ?>"width="700px" height="235px"></div>
                    <div><h3>Actual</h3></div>
                    <div><img src="<?php echo e($ultimo_odontograma[0]->odontograma); ?>"width="700px" height="235px"></div>
                <?php else: ?>
                    <div><h3>Inicial</h3></div>
                    <div><img src="<?php echo e(public_path('img/odontograma.png')); ?>" width="700px" height="235px"></div>
                <?php endif; ?>
            <?php endif; ?>
        </div>
    </div>
    <div class="page_break">
        <p class="titulo" style="font-weight:bold">PLANES DE TRATAMIENTO</p>
        <table border="solid" class="tabla-tra">
            <tr>
                <th width="350px" class="td-proc alig">Clase de Tratamiento</th>
                <th width="160px" class="td-proc alig">No. de Piezas</th>
                <th width="100px" class="td-proc alig">Honorarios</th>
            </tr>
            <tbody>
                <?php $__currentLoopData = $bd_procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $procedimiento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(sizeof($procedimientos) != 0): ?>
                        <?php $__currentLoopData = $procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $procedimiento_plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($procedimiento_plan->id == $procedimiento->id): ?>
                                <tr>
                                    <td class="td-proc fuente"><?php echo e($procedimiento_plan->nombre); ?></td>
                                    <?php if($procedimiento_plan->numero_piezas !=0 && $procedimiento_plan->honorarios !=0 ): ?>
                                        <td class="td-proc fuente" align="center"><?php echo e($procedimiento_plan->numero_piezas); ?></td>
                                        <td class="td-proc fuente" align="center">$<?php echo e(number_format($procedimiento_plan->honorarios, 2)); ?></td>
                                    <?php else: ?>
                                        <td class="td-proc fuente"></td>
                                        <td class="td-proc fuente"></td>
                                    <?php endif; ?>
                                    
                                </tr>
                                <?php break; ?>
                            <?php else: ?>
                                <?php if($loop->last): ?>
                                    <tr>
                                        <td class="td-proc fuente"><?php echo e($procedimiento->nombre); ?></td>
                                        <td class="td-proc fuente"></td>
                                        <td class="td-proc fuente"></td>
                                    </tr>
                                <?php endif; ?>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <tr>
                            <td class="td-proc fuente"><?php echo e($procedimiento->nombre); ?></td>
                            <td class="td-proc fuente"></td>
                            <td class="td-proc fuente"></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
            <tr>
                <td class="bordesB fuente" style="font-weight:bold">Costo total del presupuesto ($):</td>
                <td class="bordesA"></td>
                <td class="separador td-proc fuente">
                    $ <?php echo e($total); ?>

                </td>
            </tr>
        </table>
        <p></p>
        <p></p>
        <p></p>
        <table class="tabla-tra">
            <tr>
                <td width="325px" class="firmas">F: ____________________________</td>
                <td class="firmas">F: ____________________________</td>
            </tr>
            <tr>
                <td width="325px" class="firmas pac">Paciente</td>
                <td class="firmas" style="text-align:center">Medico</td>
            </tr>              
        </table>
    </div>
    <div class="page_break">
        <table border="solid">
            <tr align="center">
                <th width="120px" class="td-proc alig">Fecha</th>
                <th width="200px" class="td-proc alig">Tratamiento Realizado</th>
                <th width="150px" class="td-proc alig">Realizo el Tto.</th>
                <th width="60px" class="td-proc alig">Abono</th>
                <th width="60px" class="td-proc alig">Saldo</th>
                <th width="120px" class="td-proc alig">Proxima Cita</th>
            </tr>
            <tbody>

                <tr>
                    <?php if(isset($cita->pago)): ?>
                        <?php
                            $total -= $cita->pago->abono
                        ?>
                        <td class="td-proc fuente" align="center">
                            <?php
                                $date           = date_create($cita->pago->fecha_hora_inicio);
                                $formato_fecha  = date_format($date,"d-m-Y");
                            ?>
                            <?php echo e($formato_fecha); ?>

                        </td>
                        <td class="td-proc fuente" align="center">
                            <?php if($total == 0): ?>
                                <strong>Solvente</strong>
                            <?php endif; ?>
                            <?php $__currentLoopData = $cita->procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimientos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php echo e($procedimientos->nombre); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <br/>
                            <?php echo e($cita->descripcion); ?>

                        </td>
                        <td class="td-proc fuente" align="center">
                            Dr. <?php echo e($cita->pago->user->persona->primer_nombre." ".$cita->pago->user->persona->segundo_nombre." ".$cita->pago->user->persona->primer_apellido." ".$cita->pago->user->persona->segundo_apellido); ?>

                        </td>
                        <td class="td-proc fuente" align="center">
                            $ <?php echo e($cita->pago->abono); ?>

                        </td>
                        <td class="td-proc fuente" align="center">
                            $ <?php echo e(number_format($total, 2)); ?>

                        </td>
                        <td class="td-proc fuente" align="center">
                            <?php
                                $date           = date_create($citas_hijas[0]->fecha_hora_inicio);
                                $formato_fecha  = date_format($date,"d-m-Y");
                            ?>
                            <?php echo e($formato_fecha); ?>

                        </td>
                    <?php endif; ?>
                </tr>
                <?php $__currentLoopData = $citas_hijas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cita): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(isset($cita->pago)): ?>
                        <?php
                            $total -= $cita->pago->abono
                        ?>
                        <tr>
                            <td class="td-proc fuente" align="center">
                                <?php
                                    $date           = date_create($cita->fecha_hora_inicio);
                                    $formato_fecha  = date_format($date,"d-m-Y");
                                ?>
                                <?php echo e($formato_fecha); ?>

                            </td>
                            <td class="td-proc fuente" align="center">
                                <?php if($total == 0): ?>
                                    <strong>Solvente</strong>
                                <?php endif; ?>
                                <?php $__currentLoopData = $cita->procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimientos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($procedimientos->nombre); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <br/>
                                <?php echo e($cita->descripcion); ?>

                            </td>
                            <td class="td-proc fuente" align="center">
                                Dr. <?php echo e($cita->pago->user->persona->primer_nombre." ".$cita->pago->user->persona->segundo_nombre." ".$cita->pago->user->persona->primer_apellido." ".$cita->pago->user->persona->segundo_apellido); ?>

                            </td>
                            <td class="td-proc fuente" align="center">
                                
                                $ <?php echo e($cita->pago->abono); ?>

                            </td>
                            <td class="td-proc fuente" align="center">
                                $ <?php echo e(number_format($total, 2)); ?>

                            </td>
                            <td class="td-proc fuente" align="center">
                                <?php if(!$loop->last): ?>
                                    <?php
                                        $date           = date_create($citas_hijas[$key+1]->fecha_hora_inicio);
                                        $formato_fecha  = date_format($date,"d-m-Y");
                                    ?>
                                    <?php echo e($formato_fecha); ?>

                                <?php endif; ?>
                            </td>
                       </tr>
                    <?php else: ?>
                        <?php if($cita->reprogramado == 1): ?>
                            <tr>
                                <td class="td-proc fuente" align="center">
                                    <?php
                                        $date           = date_create($cita->fecha_hora_inicio);
                                        $formato_fecha  = date_format($date,"d-m-Y");
                                    ?>
                                    <?php echo e($formato_fecha); ?>

                                </td>
                                <td class="td-proc fuente" align="center">
                                    <?php if($total == 0): ?>
                                        <strong>Solvente</strong>
                                    <?php endif; ?>
                                    <br/>
                                    <strong>Cita Reprogramada</strong><br/>
                                    <?php $__currentLoopData = $cita->procedimientos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procedimientos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($procedimientos->nombre); ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <br/>
                                    <?php echo e($cita->descripcion); ?>

                                </td>
                                <td class="td-proc fuente" align="center">
                                    Cita Reprogramada
                                </td>
                                <td class="td-proc fuente" align="center">
                                    $ 0.00
                                </td>
                                <td class="td-proc fuente" align="center">
                                    $ <?php echo e(number_format($total, 2)); ?>

                                </td>
                                <td class="td-proc fuente" align="center">
                                    <?php if(!$loop->last): ?>
                                        <?php
                                            $date           = date_create($citas_hijas[$key+1]->fecha_hora_inicio);
                                            $formato_fecha  = date_format($date,"d-m-Y");
                                        ?>
                                        <?php echo e($formato_fecha); ?>

                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/expedientes/plan_tratamiento.blade.php ENDPATH**/ ?>