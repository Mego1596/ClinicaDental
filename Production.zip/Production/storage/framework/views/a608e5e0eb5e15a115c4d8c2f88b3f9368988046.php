<?php $__env->startSection('titulo'); ?>
    Lista de Usuarios
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<?php if(\Session::has('success')): ?>
    <div class="alert alert-success">
        <ul>
            <li><?php echo \Session::get('success'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<?php if(\Session::has('danger')): ?>
    <div class="alert alert-danger">
        <ul>
            <li><?php echo \Session::get('danger'); ?></li>
        </ul>
    </div>
<?php endif; ?>
<div class="panel-title">
    <h1 align="center" style="color: black">Lista de Usuarios</h1>
</div>
<div class="table-responsive">
    <table width="100%">
        <tr>
            <td width="80%">
                    <a class="btn btn-sm btn-danger" href="<?php echo e(route('home')); ?>""><i class="fas fa-arrow-circle-left"></i> Regresar</a> 
            </td>
            <td width="20%" align="right">
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.create')): ?>
                    <a href="<?php echo e(route('users.create')); ?>" class="btn btn-sm btn-success" style="color: black;"><i class="fa fa-fw fa-user-plus"></i> Registrar Usuario</a>
                <?php endif; ?>
            </td>
        </tr>
    </table>
</div>
<br/>
<br/>
<div class="pull-bottom">
    <div class="table table-responsive">
        <table id="example" class="display" style="width:100%;color: black">
            <thead>
                <tr>
                    <th style="color: black">Nombre Completo</th>
                    <th style="color: black">Nombre de Usuario</th>
                    <th style="color: black">Correo Electrónico</th>
                    <th style="color: black">Tipo de Usuario</th>
                    <th style="color: black">Acciones</th>
                </tr>
            </thead>
            <tbody>
            	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $datos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	                <?php if($datos->roles[0]['slug'] != 'paciente'): ?>
                        <tr>
                            <?php if($datos->roles[0]['slug'] == 'suspendido'): ?>
        	                    <td style="color: red"><?php echo e($datos->persona->primer_nombre.' '.$datos->persona->segundo_nombre.' '.$datos->persona->primer_apellido.' '.$datos->persona->segundo_apellido); ?></td>
                                <td style="color: red"><?php echo e($datos->name); ?></td>
        	                    <td style="color: red"><?php echo e($datos->email); ?></td>
        	                    <td style="color: red"><?php echo e($datos->roles[0]['name']); ?></td>
                            <?php else: ?>
                                <td><?php echo e($datos->persona->primer_nombre.' '.$datos->persona->segundo_nombre.' '.$datos->persona->primer_apellido.' '.$datos->persona->segundo_apellido); ?></td>
                                <td><?php echo e($datos->name); ?></td>
                                <td><?php echo e($datos->email); ?></td>
                                <td><?php echo e($datos->roles[0]['name']); ?></td>
                            <?php endif; ?>
    	                    <td>
    	                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.show')): ?>
    	                            <a href="<?php echo e(route('users.show',['user'=>$datos->id])); ?>" class="btn btn-info btn-circle" title="Ver perfil" style="color: white"><i class="fa fa-eye"></i></a>
    	                        <?php endif; ?>
    	                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.edit')): ?>
    	                            <a href="<?php echo e(route('users.edit',['user'=>$datos->id])); ?>" class="btn btn-primary btn-circle" title="Registrar Recepción de Vehículo" style="color: white" ><i class="fas fa-pencil-alt"></i></a>
    	                        <?php endif; ?>
    	                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('usuario.destroy')): ?>
    	                            <button type="button" class="btn btn-danger btn-circle" data-toggle="modal" data-target="#modal-default2<?php echo e($datos->id); ?>">
    	                                <i class="fas fa-fw fa-trash-alt"></i>
    	                            </button>
    	                        <?php endif; ?>
    	                        <div class="modal fade" id="modal-default2<?php echo e($datos->id); ?>">
    	                            <div class="modal-dialog">
    	                                <div class="modal-content">
    	                                    <div class="modal-header">
    	                                        <h4>Eliminar Usuario</h4>
    	                                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
    	                                        <span aria-hidden="true">&times;</span></button>
    	                                    </div>
    	                                    <form action="<?php echo e(route('users.destroy',['user'=>$datos->id])); ?>" method="POST">
    	                                        <?php echo csrf_field(); ?>
    	                                        <input type="hidden" name="_method" value="DELETE">
    	                                        <div class="modal-body">
    	                                            <h4>Realmente desea eliminar el usuario: <strong><?php echo e($datos->persona->primer_nombre.' '.$datos->persona->segundo_nombre.' '.$datos->persona->primer_apellido.' '.$datos->persona->segundo_apellido); ?></strong>?</h4>
    	                                        </div>
    	                                        <div class="modal-footer">
    	                                            <button type="button" class="btn btn-secondary pull-left" data-dismiss="modal">Cerrar</button>
    	                                            <button type="submit" class="btn btn-danger">Si</button>
    	                                        </div>
    	                                    </form>
    	                                </div>
    	                            </div>
    	                        </div>
    	                    </td>
    	                </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('JS'); ?>
<script type="text/javascript">
    $(function () {
        $('#example').DataTable({
            "language": {
                    "url": "//cdn.datatables.net/plug-ins/9dcbecd42ad/i18n/Spanish.json"
                },
            responsive:true,
            pagingType: "simple",
            "columnDefs": [
                { "orderable": false, "targets": 4 }
            ]
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Mego\Desktop\Sistema-Dental\SanaDental\resources\views/usuarios/index.blade.php ENDPATH**/ ?>